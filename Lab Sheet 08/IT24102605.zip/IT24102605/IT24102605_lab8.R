setwd("C:\\Users\\User\\Desktop\\IT24102605")
gedata:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAkCAYAAAD7PHgWAAACYklEQVR4Xu2WzW/SYBzHp/Hicf+HJ/8AL/4BHrwbz+ppB6/c1OGQAaXAQGBjONZB6mp5LZSXSkY0mhhjjPNlW9DJkAHLJJ7Mz+dpopEfgfDWdUv6Sb6BtL/0+8lDy9OZGQMDA4MuREWZxcdODWlZYWVlC+hnOl++hM/rTkouAeXDpx2g39O54hU8oyvJbFEVbLaO4OPnXUjlSpCSStfwnC6YTKbziUz+nyDNl90qUOmEJN/A85qQz+cviKIy2y/JbKFLkGavuq9KCkn5Fr7e2Ahx6f5mQmqTwP8Rklmgq9QvGVnpEaSpfqupkpuJ7F3cNRa8mG6rTWOCBWn2a3VyTxaBj6dNuG9kYkJSFWy1e4smSe2gQf6CShAVUg9w50hwT8Xf/VZi0tQbTZAKCnB83IJ7hyYSE/r+VNNI47AFuWIZSI8ddw9FeIPXVJDmsNmGwvMKrG7wTo7jLmKHgYQiMc0F/6ZceQmhSHQOOwwk+IQ7EUG6isVyBYJr67exw0D8oYjmgg0ilyFPdGB1naG7EHYYiHc5rKngD/IkP0tJ4F0J23D3UHgCIc0ED+oNiAkJ8PhXFnDv0LC+oCaCdDdZi/JArn8Pd44Es+SfumD163dYJg+f0xuYfKuzu3ys3e2DcdI+Ou6R29mrgo/c1w6XbzovC+NiZZeg0/nVJbdN3q7Zx0FYdHnu4PkT5xHj7hJ8934bHGRVLU7XTTyrCwt2Fo5/dlS512/egtXpBovDdR3P6YbZ5lTltl68godEdt7GXMUzumK22lnzIgPzVgeYrcxlfP5UQLct8g91Dh83MDir/AHpRAm26kXeCQAAAABJRU5ErkJggg==twd()

data<-read.table("Exercise - LaptopsWeights.txt", header=TRUE)
fix(data)
attach(data)

#Q1
popmn<-mean(Weight.kg.)
popvar<-var(Weight.kg.)
pop_dev <- sd(Weight.kg.)

#Q2
samples<-c()
n<-c()

for(i in 25){
  s<-sample(Weight.kg.,6,replace=TRUE)
  samples<-cbind(samples,s)
  n<-c(n,paste('s',i))
}
colnames(samples)=n

s.means<-apply(samples,2,mean)
s.vars<-apply(samples,2,var)
s.dev<-apply(samples,2,sd)

#Q3
samplemean<-mean(s.means)
sampledev<-sd(s.means)

popmn
samplemean

pop_dev
sampledev

